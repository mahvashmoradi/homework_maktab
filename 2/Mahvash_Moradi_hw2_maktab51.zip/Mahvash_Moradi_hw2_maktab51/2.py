str_1=input('enter your string: ')
rev_str_1=str_1[::-1]
if str_1==rev_str_1:
    print('True')
else:
    print('False')
