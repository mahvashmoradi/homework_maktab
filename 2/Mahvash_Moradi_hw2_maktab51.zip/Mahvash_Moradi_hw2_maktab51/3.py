Main_string=input('enter Main string: ')
Sub_string=input('enter Subtring strng: ')
if Sub_string in Main_string:
    print('Yes')
else:
    print('No')
