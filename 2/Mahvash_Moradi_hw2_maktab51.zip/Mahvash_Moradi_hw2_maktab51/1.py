ch='*'
len_pattern=5
for i in range(1,len_pattern):
    print(ch*i)

for i in range(len_pattern,0,-1):
    print(ch*i)

