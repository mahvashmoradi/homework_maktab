<?php


$x = $_POST['num1'];
$y = $_POST['num2'];
echo 'Add: ';
echo $x+$y ;
echo '<br/>'."\n";

echo 'Multiplication: '. $x*$y ;
echo '<br/>'."\n";

echo 'Submission : ';
echo $x-$y ;
echo '<br/>'."\n";


echo 'Division: '. $x/$y;

?>